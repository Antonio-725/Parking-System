/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package parkingsoftware;

import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;


/**
 *
 * @author antonio
 */
public class ParkingSoftware {
    public String name;
    Boolean Conn;
    
    
    
    public String getName(){
        return this.name;
    }
}
  
        

    /**
     * @param args the command line arguments
     */
    
    

